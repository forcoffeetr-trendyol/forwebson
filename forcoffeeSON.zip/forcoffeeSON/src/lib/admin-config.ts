export type AdminCredentials = {
  email: string;
  password: string;
};

export function getConfiguredAdminCredentials(): AdminCredentials {
  const env = import.meta.env ?? {};

  const email = (
    env.VITE_ADMIN_EMAIL ??
    env.ADMIN_EMAIL ??
    process.env?.VITE_ADMIN_EMAIL ??
    process.env?.ADMIN_EMAIL ??
    ""
  ) as string;

  const password = (
    env.VITE_ADMIN_PASSWORD ??
    env.ADMIN_PASSWORD ??
    process.env?.VITE_ADMIN_PASSWORD ??
    process.env?.ADMIN_PASSWORD ??
    ""
  ) as string;

  return {
    email: String(email).trim(),
    password: String(password).trim(),
  };
}

export function isConfiguredAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  const configured = getConfiguredAdminCredentials();
  return configured.email.length > 0 && configured.email.toLowerCase() === email.toLowerCase();
}
