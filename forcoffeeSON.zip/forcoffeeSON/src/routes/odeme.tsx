import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Check, CreditCard, MapPin, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";

import { useCart } from "@/context/CartContext";
import { fiyatBicimle } from "@/data/urunler";

type CheckoutStep = "adres" | "odeme" | "onay" | "basarili";

type AdresForm = {
  adSoyad: string;
  telefon: string;
  sehir: string;
  ilce: string;
  adres: string;
  not: string;
};

type OdemeForm = {
  kartSahibi: string;
  kartNumarasi: string;
  sonKullanma: string;
  cvc: string;
};

export const Route = createFileRoute("/odeme")({
  head: () => ({
    meta: [
      { title: "Ödeme — FOR COFFEE" },
      {
        name: "description",
        content: "Teslimat bilgilerini girin, ödeme yöntemini seçin ve siparişinizi onaylayın.",
      },
      { property: "og:title", content: "Ödeme | FOR COFFEE" },
      { property: "og:description", content: "FOR COFFEE sipariş ödemesi ve teslimat adımı." },
    ],
  }),
  component: OdemeSayfasi,
});

function OdemeSayfasi() {
  const { kalemler, temizle, araToplam, toplamAdet } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<CheckoutStep>("adres");
  const [odemeYontemi, setOdemeYontemi] = useState("kredi-karti");
  const [orderNumber, setOrderNumber] = useState("");
  const [form, setForm] = useState<AdresForm>({
    adSoyad: "",
    telefon: "",
    sehir: "İstanbul",
    ilce: "Kadıköy",
    adres: "",
    not: "",
  });
  const [odemeForm, setOdemeForm] = useState<OdemeForm>({
    kartSahibi: "",
    kartNumarasi: "",
    sonKullanma: "",
    cvc: "",
  });

  const kargoBedavaSeviyesi = 750;
  const kargo = araToplam > 0 && araToplam < kargoBedavaSeviyesi ? 79 : 0;
  const toplam = araToplam + kargo;
  const oncelikliUrun = kalemler[0];

  const adimlar = useMemo(
    () => [
      { key: "adres", label: "Teslimat" },
      { key: "odeme", label: "Ödeme" },
      { key: "onay", label: "Onay" },
    ],
    [],
  );

  const activeIndex = adimlar.findIndex((item) => item.key === step);

  if (kalemler.length === 0 && step !== "basarili") {
    return (
      <div className="checkout-shell checkout-empty-state">
        <div className="checkout-card empty-checkout-card">
          <div className="checkout-empty-icon">
            <ShieldCheck size={32} />
          </div>
          <h1>Sepetiniz boş</h1>
          <p>Ödeme adımına geçmeden önce en az bir ürün ekleyin.</p>
          <Link to="/magaza" className="cart-primary-button">
            Mağazaya dön <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    );
  }

  const handleChange = (field: keyof AdresForm, value: string) => {
    setForm((onceki) => ({ ...onceki, [field]: value }));
  };

  const toStep = (next: CheckoutStep) => setStep(next);

  const adresFormuDogru =
    form.adSoyad.trim() &&
    form.telefon.trim() &&
    form.sehir.trim() &&
    form.ilce.trim() &&
    form.adres.trim();

  const odemeFormuDogru =
    odemeYontemi === "kredi-karti"
      ? odemeForm.kartSahibi.trim() &&
        odemeForm.kartNumarasi.replace(/\s+/g, "").length >= 12 &&
        odemeForm.sonKullanma.trim() &&
        odemeForm.cvc.trim().length >= 3
      : true;

  const nextStep = () => {
    if (step === "adres") {
      if (!adresFormuDogru) return;
      return toStep("odeme");
    }
    if (step === "odeme") {
      if (!odemeFormuDogru) return;
      return toStep("onay");
    }
    if (step === "onay") {
      const generatedOrder = `FC-${Date.now().toString().slice(-6)}`;
      setOrderNumber(generatedOrder);
      temizle();
      return toStep("basarili");
    }
    return undefined;
  };

  const previousStep = () => {
    if (step === "odeme") return toStep("adres");
    if (step === "onay") return toStep("odeme");
    return undefined;
  };

  const handleCardInput = (field: keyof OdemeForm, value: string) => {
    let nextValue = value;
    if (field === "kartNumarasi") {
      nextValue = value
        .replace(/\D/g, "")
        .slice(0, 16)
        .replace(/(.{4})/g, "$1 ")
        .trim();
    }
    if (field === "sonKullanma") {
      nextValue = value
        .replace(/\D/g, "")
        .slice(0, 4)
        .replace(/(\d{2})(\d)/, "$1/$2");
    }
    if (field === "cvc") {
      nextValue = value.replace(/\D/g, "").slice(0, 4);
    }
    setOdemeForm((onceki) => ({ ...onceki, [field]: nextValue }));
  };

  if (step === "basarili") {
    return (
      <div className="checkout-shell">
        <div className="checkout-success-card">
          <div className="checkout-success-badge">
            <Check size={24} />
          </div>
          <span className="checkout-kicker">Sipariş alındı</span>
          <h1>Siparişiniz için teşekkür ederiz.</h1>
          <p>
            Teslimat bilgileri ve ödeme onayı kaydedildi. Siparişiniz en kısa sürede hazırlanacak.
          </p>
          <div className="checkout-success-meta">
            <span>Sipariş no</span>
            <strong>{orderNumber || "FC-000000"}</strong>
          </div>
          <div className="checkout-success-meta secondary-meta">
            <span>Toplam ödeme</span>
            <strong>{fiyatBicimle(toplam)}</strong>
          </div>
          <div className="checkout-success-actions">
            <button type="button" className="cart-primary-button" onClick={() => navigate({ to: "/magaza" })}>
              Alışverişe devam et <ArrowRight size={16} />
            </button>
            <Link to="/" className="checkout-secondary-link">
              Ana sayfaya dön
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="checkout-shell desktop-storefront mx-auto px-6 py-16 md:py-28 desktop-page-space">
      <nav className="cart-breadcrumb" aria-label="Breadcrumb">
        <Link to="/">Ana Sayfa</Link>
        <span>/</span>
        <Link to="/sepet">Sepet</Link>
        <span>/</span>
        <strong>Ödeme</strong>
      </nav>

      <header className="checkout-header">
        <div>
          <span className="heading-eyebrow">Sipariş</span>
          <h1>Ödeme ve teslimat</h1>
        </div>
        <div className="checkout-total-badge">{toplamAdet} ürün</div>
      </header>

      <div className="checkout-layout">
        <section className="checkout-card checkout-main-card">
          <div className="checkout-progress">
            {adimlar.map((adim, index) => {
              const isActive = index === activeIndex;
              const isDone = index < activeIndex;
              return (
                <div key={adim.key} className={`checkout-step ${isActive ? "active" : ""} ${isDone ? "done" : ""}`}>
                  <span>{index + 1}</span>
                  <strong>{adim.label}</strong>
                </div>
              );
            })}
          </div>

          {step === "adres" && (
            <div className="checkout-form">
              <div className="checkout-section-header">
                <MapPin size={18} />
                <h2>Teslimat adresi</h2>
              </div>

              <div className="checkout-grid two-cols">
                <label>
                  <span>Ad Soyad</span>
                  <input value={form.adSoyad} onChange={(e) => handleChange("adSoyad", e.target.value)} placeholder="Adınız Soyadınız" />
                </label>
                <label>
                  <span>Telefon</span>
                  <input value={form.telefon} onChange={(e) => handleChange("telefon", e.target.value)} placeholder="05xx xxx xx xx" />
                </label>
              </div>

              <div className="checkout-grid two-cols">
                <label>
                  <span>Şehir</span>
                  <input value={form.sehir} onChange={(e) => handleChange("sehir", e.target.value)} placeholder="Şehir" />
                </label>
                <label>
                  <span>İlçe</span>
                  <input value={form.ilce} onChange={(e) => handleChange("ilce", e.target.value)} placeholder="İlçe" />
                </label>
              </div>

              <label>
                <span>Adres</span>
                <textarea rows={4} value={form.adres} onChange={(e) => handleChange("adres", e.target.value)} placeholder="Mahalle, sokak, daire no" />
              </label>

              <label>
                <span>Not</span>
                <textarea rows={3} value={form.not} onChange={(e) => handleChange("not", e.target.value)} placeholder="Kapı girişi, teslimat notu vb." />
              </label>
            </div>
          )}

          {step === "odeme" && (
            <div className="checkout-form">
              <div className="checkout-section-header">
                <CreditCard size={18} />
                <h2>Ödeme yöntemi</h2>
              </div>

              <div className="payment-methods">
                {[
                  { id: "kredi-karti", title: "Kredi kartı", desc: "Visa / Mastercard / Amex" },
                  { id: "banka-havale", title: "Banka Havalesi", desc: "Manuel ödeme onayı" },
                  { id: "kapida-odeme", title: "Kapıda ödeme", desc: "Kart / nakit seçenekleri" },
                ].map((method) => (
                  <button
                    key={method.id}
                    type="button"
                    className={`payment-option ${odemeYontemi === method.id ? "selected" : ""}`}
                    onClick={() => setOdemeYontemi(method.id)}
                  >
                    <div>
                      <strong>{method.title}</strong>
                      <span>{method.desc}</span>
                    </div>
                    <span className="payment-radio" aria-hidden="true" />
                  </button>
                ))}
              </div>

              {odemeYontemi === "kredi-karti" && (
                <div className="payment-form-grid">
                  <label>
                    <span>Kart sahibi</span>
                    <input
                      value={odemeForm.kartSahibi}
                      onChange={(e) => handleCardInput("kartSahibi", e.target.value)}
                      placeholder="Ad Soyad"
                    />
                  </label>
                  <label>
                    <span>Kart numarası</span>
                    <input
                      value={odemeForm.kartNumarasi}
                      onChange={(e) => handleCardInput("kartNumarasi", e.target.value)}
                      placeholder="1234 5678 9012 3456"
                    />
                  </label>
                  <div className="checkout-grid two-cols">
                    <label>
                      <span>Son kullanma</span>
                      <input
                        value={odemeForm.sonKullanma}
                        onChange={(e) => handleCardInput("sonKullanma", e.target.value)}
                        placeholder="MM/YY"
                      />
                    </label>
                    <label>
                      <span>CVC</span>
                      <input
                        value={odemeForm.cvc}
                        onChange={(e) => handleCardInput("cvc", e.target.value)}
                        placeholder="123"
                      />
                    </label>
                  </div>
                </div>
              )}

              {odemeYontemi !== "kredi-karti" && (
                <div className="payment-note-box">
                  <strong>
                    {odemeYontemi === "banka-havale"
                      ? "Banka havalesi seçildi"
                      : "Kapıda ödeme seçildi"}
                  </strong>
                  <p>
                    {odemeYontemi === "banka-havale"
                      ? "Ödeme bilgileri sipariş onayından sonra e-posta ile iletilecek."
                      : "Siparişiniz teslimat sırasında ödeme için hazır olacak."}
                  </p>
                </div>
              )}
            </div>
          )}

          {step === "onay" && (
            <div className="checkout-form">
              <div className="checkout-section-header">
                <Check size={18} />
                <h2>Sipariş onayı</h2>
              </div>

              <div className="confirmation-panel">
                <div className="confirmation-row">
                  <span>Adres</span>
                  <strong>{form.adSoyad}</strong>
                </div>
                <div className="confirmation-row">
                  <span>İletişim</span>
                  <strong>{form.telefon}</strong>
                </div>
                <div className="confirmation-row multiline">
                  <span>Teslimat</span>
                  <strong>
                    {form.sehir} / {form.ilce}
                    <br />
                    {form.adres}
                  </strong>
                </div>
                <div className="confirmation-row">
                  <span>Ödeme</span>
                  <strong>
                    {odemeYontemi === "kredi-karti"
                      ? "Kredi kartı"
                      : odemeYontemi === "banka-havale"
                        ? "Banka Havalesi"
                        : "Kapıda ödeme"}
                  </strong>
                </div>
              </div>
            </div>
          )}

          <div className="checkout-actions">
            {step !== "adres" && (
              <button type="button" className="checkout-back-button" onClick={previousStep}>
                Geri
              </button>
            )}
            <button
              type="button"
              className="cart-primary-button"
              onClick={nextStep}
              disabled={
                (step === "adres" && !adresFormuDogru) ||
                (step === "odeme" && !odemeFormuDogru)
              }
            >
              {step === "onay" ? "Siparişi onayla" : "Devam et"}
            </button>
          </div>
        </section>

        <aside className="checkout-card checkout-summary-card">
          <div className="checkout-summary-header">Sipariş özeti</div>

          {oncelikliUrun && (
            <div className="checkout-feature-card">
              <div className="checkout-feature-image">
                {oncelikliUrun.gorsel && <img src={oncelikliUrun.gorsel} alt={oncelikliUrun.ad} />}
              </div>
              <div className="checkout-feature-copy">
                <span>Öne çıkan ürün</span>
                <strong>{oncelikliUrun.ad}</strong>
                <small>
                  {oncelikliUrun.varyantEtiket}
                  {oncelikliUrun.ogutme ? ` · ${oncelikliUrun.ogutme}` : ""}
                </small>
              </div>
              <div className="checkout-feature-price">
                <span>{oncelikliUrun.adet}x</span>
                <strong>{fiyatBicimle(oncelikliUrun.fiyat * oncelikliUrun.adet)}</strong>
              </div>
            </div>
          )}

          <div className="summary-items">
            {kalemler.map((k) => (
              <div key={k.anahtar} className="summary-item">
                <div className="summary-item-copy">
                  <strong>{k.ad}</strong>
                  <span>
                    {k.varyantEtiket}
                    {k.ogutme ? ` · ${k.ogutme}` : ""}
                  </span>
                </div>
                <div className="summary-item-price">
                  <span>{k.adet}x</span>
                  <strong>{fiyatBicimle(k.fiyat * k.adet)}</strong>
                </div>
              </div>
            ))}
          </div>

          <div className="checkout-summary-lines">
            <div>
              <span>Ara toplam</span>
              <strong>{fiyatBicimle(araToplam)}</strong>
            </div>
            <div>
              <span>Kargo</span>
              <strong>{kargo === 0 ? "Ücretsiz" : fiyatBicimle(kargo)}</strong>
            </div>
            <div className="total-line">
              <span>Toplam</span>
              <strong>{fiyatBicimle(toplam)}</strong>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
