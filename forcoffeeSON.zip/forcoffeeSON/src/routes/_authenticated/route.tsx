import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { getConfiguredAdminCredentials, isConfiguredAdminEmail } from "@/lib/admin-config";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { email: configuredAdminEmail } = getConfiguredAdminCredentials();
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });

    if (configuredAdminEmail && isConfiguredAdminEmail(data.user.email)) {
      return { user: data.user, roles: [{ role: "admin" }] };
    }

    const { data: roles, error: roleError } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", data.user.id);
    if (roleError || !roles?.some((row) => row.role === "admin" || row.role === "editor")) {
      throw redirect({ to: "/auth" });
    }
    return { user: data.user, roles };
  },
  component: () => <Outlet />,
});
