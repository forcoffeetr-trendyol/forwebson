import { createFileRoute } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import BestSellers from "@/components/magaza/BestSellers";
import BrewingMethods from "@/components/magaza/BrewingMethods";
import CategoryCarousel from "@/components/magaza/CategoryCarousel";
import CoffeeAcademy from "@/components/magaza/CoffeeAcademy";
import Equipment from "@/components/magaza/Equipment";
import FeaturedProduct from "@/components/magaza/FeaturedProduct";
import HeroSection from "@/components/magaza/HeroSection";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FOR COFFEE — Özel Kahve Koleksiyonu ve Kahve Akademisi" },
      {
        name: "description",
        content:
          "Tek köken çekirdekler, özel harmanlar ve ekipmanlar. Dijital Kahve Akademisi ile demleme, kavurma ve espresso bilgisi tek çatı altında.",
      },
      { property: "og:title", content: "FOR COFFEE — Özel Kahve Koleksiyonu ve Akademi" },
      {
        property: "og:description",
        content: "Çekirdekten fincana: premium kahve, ekipman ve Türkçe kahve eğitimi.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: AnaSayfa,
});

function AnaSayfa() {
  const navigate = useNavigate();
  const magazayaGit = () => navigate({ to: "/magaza" });
  const yonlendir = (sayfa: string) =>
    sayfa === "brewing" ? navigate({ to: "/demleme" }) : navigate({ to: "/magaza" });

  return (
    <>
      <HeroSection />
      <CategoryCarousel />
      <BestSellers onShopClick={magazayaGit} />
      <FeaturedProduct />
      <BrewingMethods onNavigate={yonlendir} />
      <Equipment onNavigate={yonlendir} />
      <CoffeeAcademy />
    </>
  );
}
