import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Minus, Plus, ShieldCheck, ShoppingBag, Sparkles, Trash2 } from "lucide-react";

import { useCart } from "@/context/CartContext";
import { fiyatBicimle } from "@/data/urunler";

export const Route = createFileRoute("/sepet")({
  head: () => ({
    meta: [
      { title: "Sepetim — FOR COFFEE" },
      {
        name: "description",
        content:
          "Seçtiğiniz taze kavrulmuş kahveleri gözden geçirin, gramaj ve öğütme tercihlerinizi kontrol edip siparişinizi tamamlayın.",
      },
      { property: "og:title", content: "Sepetim | FOR COFFEE" },
      {
        property: "og:description",
        content: "Sepetinizdeki kahveleri inceleyin ve siparişinizi tamamlayın.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SepetSayfasi,
});

function SepetSayfasi() {
  const { kalemler, adetAyarla, kaldir, temizle, araToplam } = useCart();
  const kargoBedavaSeviyesi = 750;
  const kargo = araToplam > 0 && araToplam < kargoBedavaSeviyesi ? 79 : 0;
  const kargoKalan = Math.max(kargoBedavaSeviyesi - araToplam, 0);
  const kargoProgress = araToplam > 0 ? Math.min((araToplam / kargoBedavaSeviyesi) * 100, 100) : 0;
  const toplam = araToplam + kargo;

  return (
    <div className="cart-page-shell desktop-storefront mx-auto px-6 py-16 md:py-28 desktop-page-space">
      <nav className="cart-breadcrumb" aria-label="Breadcrumb">
        <Link to="/">Ana Sayfa</Link>
        <span>/</span>
        <Link to="/magaza">Mağaza</Link>
        <span>/</span>
        <strong>Sipariş Özeti</strong>
      </nav>

      <header className="cart-page-header">
        <div>
          <span className="heading-eyebrow">Sepetiniz</span>
          <h1>Ön siparişinizi hazırlayın</h1>
        </div>
        <div className="cart-page-meta">
          <span>{kalemler.length} ürün</span>
          <strong>{fiyatBicimle(araToplam)}</strong>
        </div>
      </header>

      {kalemler.length === 0 ? (
        <div className="cart-empty-state">
          <div className="cart-empty-icon">
            <ShoppingBag size={38} />
          </div>
          <h2>Sepetiniz şu an boş</h2>
          <p>
            Taze kavrulmuş tek kökenler, harmanlar ve demleme ekipmanlarıyla kahve rutininizi
            yeniden kurun.
          </p>
          <Link to="/magaza" className="cart-primary-button">
            Mağazaya dön <ArrowRight size={16} />
          </Link>
        </div>
      ) : (
        <div className="cart-page-grid">
          <div className="cart-page-main">
            <section className="cart-panel">
              <div className="cart-panel-head">
                <h2>Seçilen ürünler</h2>
                <button type="button" onClick={temizle} className="cart-text-button">
                  Sepeti boşalt
                </button>
              </div>

              <div className="cart-items-list">
                {kalemler.map((k) => (
                  <article key={k.anahtar} className="cart-item-card">
                    <div className="cart-item-image">
                      {k.gorsel && (
                        <img src={k.gorsel} alt={`${k.ad} ürün görseli`} loading="lazy" />
                      )}
                    </div>

                    <div className="cart-item-details">
                      <div className="cart-item-topline">
                        <Link to="/urun/$slug" params={{ slug: k.slug }} className="cart-item-name">
                          {k.ad}
                        </Link>
                        <button
                          type="button"
                          onClick={() => kaldir(k.anahtar)}
                          className="cart-remove-button"
                          aria-label={`${k.ad} ürününü kaldır`}
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>

                      <div className="cart-item-meta">
                        <span>{k.varyantEtiket}</span>
                        {k.ogutme ? <span>{k.ogutme}</span> : null}
                      </div>

                      <div className="cart-item-actions">
                        <div className="cart-quantity-box" aria-label="Ürün adedi">
                          <button type="button" onClick={() => adetAyarla(k.anahtar, k.adet - 1)} aria-label="Adet azalt">
                            <Minus size={14} />
                          </button>
                          <strong>{k.adet}</strong>
                          <button type="button" onClick={() => adetAyarla(k.anahtar, k.adet + 1)} aria-label="Adet artır">
                            <Plus size={14} />
                          </button>
                        </div>

                        <div className="cart-price-wrap">
                          <span className="cart-unit-price">{fiyatBicimle(k.fiyat)} / adet</span>
                          <strong>{fiyatBicimle(k.fiyat * k.adet)}</strong>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          </div>

          <aside className="cart-summary-panel">
            <div className="cart-summary-box">
              <div className="summary-kicker">Sipariş özeti</div>

              <div className="shipping-progress-box">
                <div className="shipping-meta">
                  <span>Kargo</span>
                  <strong>{kargo === 0 ? "Ücretsiz" : fiyatBicimle(kargo)}</strong>
                </div>
                <div className="shipping-progress-track">
                  <span style={{ width: `${kargoProgress}%` }} />
                </div>
                <p>
                  {kargoKalan > 0
                    ? `${fiyatBicimle(kargoKalan)} daha ekleyin, ücretsiz kargo kazanın.`
                    : "Kargo bedava!"}
                </p>
              </div>

              <div className="summary-line">
                <span>Ara toplam</span>
                <strong>{fiyatBicimle(araToplam)}</strong>
              </div>
              <div className="summary-line">
                <span>Kurye / kargo</span>
                <strong>{kargo === 0 ? "Ücretsiz" : fiyatBicimle(kargo)}</strong>
              </div>
              <div className="summary-line total-row">
                <span>Toplam</span>
                <strong>{fiyatBicimle(toplam)}</strong>
              </div>

              <div className="coupon-box">
                <label htmlFor="kupon-kodu">Kupon / promosyon</label>
                <div className="coupon-row">
                  <input id="kupon-kodu" type="text" placeholder="Kod girin" />
                  <button type="button">Uygula</button>
                </div>
              </div>

              <Link to="/odeme" className="cart-primary-button checkout-button">
                Ödemeye geç <ArrowRight size={16} />
              </Link>

              <Link to="/magaza" className="cart-secondary-link">
                Alışverişe devam et
              </Link>
            </div>

            <div className="cart-trust-box">
              <div className="trust-item">
                <ShieldCheck size={16} />
                <span>Güvenli ödeme</span>
              </div>
              <div className="trust-item">
                <Sparkles size={16} />
                <span>Özenle paketlenir</span>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
