import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from "lucide-react";

import { useCart } from "@/context/CartContext";
import { fiyatBicimle } from "@/data/urunler";

/** Mini sepet çekmecesi — global, tüm sayfalarda erişilebilir. */
export default function SepetCekmecesi() {
  const { kalemler, cekmeceAcik, cekmeceKapat, adetAyarla, kaldir, araToplam, toplamAdet } =
    useCart();

  useEffect(() => {
    if (!cekmeceAcik) return;
    const oncekiOverflow = document.body.style.overflow;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") cekmeceKapat();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = oncekiOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [cekmeceAcik, cekmeceKapat]);

  const kargoBedavaSeviyesi = 750;
  const kargo = araToplam > 0 && araToplam < kargoBedavaSeviyesi ? 79 : 0;
  const toplam = araToplam + kargo;

  return (
    <>
      <div
        onClick={cekmeceKapat}
        aria-hidden={!cekmeceAcik}
        role="presentation"
        className={`cart-drawer-overlay transition-opacity duration-300 ${
          cekmeceAcik ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      <aside
        role="dialog"
        aria-label="Sepet"
        aria-modal={cekmeceAcik}
        className={`cart-drawer transition-transform duration-300 ease-out ${
          cekmeceAcik ? "translate-x-0" : "translate-x-full"
        }`}
        style={{ backgroundColor: "var(--bg-primary, hsl(var(--background)))" }}
      >
        <header className="cart-drawer-header" style={{ borderColor: "rgba(201,169,110,0.20)" }}>
          <div>
            <span className="cart-drawer-kicker">SEPET</span>
            <h2>
              Sepetim
              <small>({toplamAdet} ürün)</small>
            </h2>
          </div>
          <button onClick={cekmeceKapat} aria-label="Sepeti kapat" className="cart-drawer-close">
            <X size={18} />
          </button>
        </header>

        {kalemler.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
            <div className="cart-empty-icon cart-empty-icon-small">
              <ShoppingBag size={32} />
            </div>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              Sepetiniz henüz boş. Taze kavrulmuş çekirdeklerimizi keşfedin.
            </p>
            <Link
              to="/magaza"
              onClick={cekmeceKapat}
              className="cart-primary-button"
              style={{ width: "100%", justifyContent: "center" }}
            >
              Mağazaya git <ArrowRight size={16} />
            </Link>
          </div>
        ) : (
          <>
            <div className="cart-drawer-body">
              {kalemler.map((k) => (
                <div key={k.anahtar} className="cart-drawer-item">
                  <div className="cart-drawer-image">
                    {k.gorsel && <img src={k.gorsel} alt={k.ad} loading="lazy" />}
                  </div>

                  <div className="cart-drawer-item-content">
                    <Link
                      to="/urun/$slug"
                      params={{ slug: k.slug }}
                      onClick={cekmeceKapat}
                      className="cart-drawer-item-name"
                    >
                      {k.ad}
                    </Link>
                    <p className="cart-drawer-item-meta">
                      {k.varyantEtiket}
                      {k.ogutme ? ` · ${k.ogutme}` : ""}
                    </p>

                    <div className="cart-drawer-item-actions">
                      <div className="cart-quantity-box cart-quantity-box-small">
                        <button
                          type="button"
                          aria-label="Adet azalt"
                          onClick={() => adetAyarla(k.anahtar, k.adet - 1)}
                        >
                          <Minus size={12} />
                        </button>
                        <strong>{k.adet}</strong>
                        <button
                          type="button"
                          aria-label="Adet artır"
                          onClick={() => adetAyarla(k.anahtar, k.adet + 1)}
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <div className="cart-drawer-price-wrap">
                        <span>{fiyatBicimle(k.fiyat * k.adet)}</span>
                        <button aria-label="Ürünü kaldır" onClick={() => kaldir(k.anahtar)}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <footer className="cart-drawer-footer">
              <div className="cart-drawer-summary-row">
                <span>Ara toplam</span>
                <strong>{fiyatBicimle(araToplam)}</strong>
              </div>
              <div className="cart-drawer-summary-row">
                <span>Kargo</span>
                <strong>{kargo === 0 ? "Ücretsiz" : fiyatBicimle(kargo)}</strong>
              </div>
              <div className="cart-drawer-summary-row cart-drawer-total-row">
                <span>Toplam</span>
                <strong>{fiyatBicimle(toplam)}</strong>
              </div>

              <Link to="/sepet" onClick={cekmeceKapat} className="cart-primary-button">
                Sepete git <ArrowRight size={16} />
              </Link>
            </footer>
          </>
        )}
      </aside>
    </>
  );
}
