import { Bean, BriefcaseBusiness, Coffee, Leaf } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { KATEGORILER, URUNLER } from "@/data/urunler";

const icons = {
  "tek-koken": Coffee,
  harman: Bean,
  cay: Leaf,
  ekipman: BriefcaseBusiness,
} as const;

const labels = {
  "tek-koken": "Tek",
  harman: "Harman",
  cay: "Çay",
  ekipman: "Ekipman",
} as const;

const CategoryCarousel = () => (
  <section className="container-luxury py-10">
    <div className="mb-6 flex items-end justify-between">
      <div>
        <span className="heading-eyebrow">Koleksiyonu keşfet</span>
        <h2 className="mt-2 text-2xl font-serif" style={{ color: "var(--text-primary)" }}>
          Kategoriler
        </h2>
      </div>
      <Link to="/magaza" className="text-sm font-medium" style={{ color: "var(--accent)" }}>
        Tümünü gör
      </Link>
    </div>

    <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
      {KATEGORILER.map((category) => {
        const Icon = icons[category.slug];
        const count = URUNLER.filter((product) => product.kategori === category.slug).length;
        const label = labels[category.slug] ?? category.ad;

        return (
          <Link
            key={category.slug}
            to="/magaza"
            className="group flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-1"
          >
            <div
              className="mb-4 flex h-28 w-28 items-center justify-center rounded-full border transition-all duration-300 group-hover:scale-[1.03] md:h-32 md:w-32"
              style={{
                borderColor: "rgba(201,169,110,0.7)",
                backgroundColor: "var(--bg-secondary)",
                boxShadow: "inset 0 0 0 1px rgba(201,169,110,0.18), 0 12px 30px rgba(15,23,42,0.04)",
              }}
            >
              <Icon size={52} strokeWidth={1.5} style={{ color: "var(--accent)" }} />
            </div>

            <strong
              className="text-xl font-medium tracking-[-0.04em] md:text-2xl"
              style={{ color: "var(--text-primary)" }}
            >
              {label}
            </strong>

            <small className="mt-1 text-xs tracking-[0.16em] uppercase" style={{ color: "var(--text-muted)" }}>
              {count} ürün
            </small>
          </Link>
        );
      })}
    </div>
  </section>
);

export default CategoryCarousel;
